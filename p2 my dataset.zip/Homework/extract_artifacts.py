import os
import pefile
import glob

# Функция для анализа папки и создания CSV файла
def process_folder(folder_path, output_filename):
    # Открываем CSV файл для записи
    with open(output_filename, 'w') as csv_file:
        # Записываем заголовки
        csv_file.write("AddressOfEntryPoint,DllCharacteristics,NumberOfSections,ResourceSize\n")

        # Ищем все файлы в указанной папке
        files = glob.glob(os.path.join(folder_path, '*.*'))

        for file_path in files:
            try:
                # Анализируем PE файл
                pe = pefile.PE(file_path)
                
                # Записываем характеристики в CSV
                csv_file.write(f"{pe.OPTIONAL_HEADER.AddressOfEntryPoint},")
                csv_file.write(f"{pe.OPTIONAL_HEADER.DllCharacteristics},")
                csv_file.write(f"{pe.FILE_HEADER.NumberOfSections},")
                csv_file.write(f"{pe.OPTIONAL_HEADER.DATA_DIRECTORY[2].Size}\n")
            except Exception as e:
                print(f"Не удалось проанализировать файл {file_path}: {e}")

    print(f"Файл {output_filename} успешно создан.")